#!/system/bin/sh

# Удаляем логи
rm -f /data/local/tmp/max_blocker.log

echo "Пока!"
